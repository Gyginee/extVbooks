function execute() {
    return Response.success([{
        title: "Tất cả thể loại",
        input: "https://www.nettruyen.dev/tim-truyen",
        script: "gen.js"
    }, {
        title: "Action",
        input: "https://www.nettruyen.dev/tim-truyen/action",
        script: "gen.js"
    }, {
        title: "Adult",
        input: "https://www.nettruyen.dev/tim-truyen/truong-thanh",
        script: "gen.js"
    }, {
        title: "Adventure",
        input: "https://www.nettruyen.dev/tim-truyen/adventure",
        script: "gen.js"
    }, {
        title: "Anime",
        input: "https://www.nettruyen.dev/tim-truyen/anime",
        script: "gen.js"
    }, {
        title: "Chuyển Sinh",
        input: "https://www.nettruyen.dev/tim-truyen/chuyen-sinh",
        script: "gen.js"
    }, {
        title: "Comedy",
        input: "https://www.nettruyen.dev/tim-truyen/comedy",
        script: "gen.js"
    }, {
        title: "Comic",
        input: "https://www.nettruyen.dev/tim-truyen/comic",
        script: "gen.js"
    }, {
        title: "Cooking",
        input: "https://www.nettruyen.dev/tim-truyen/cooking",
        script: "gen.js"
    }, {
        title: "Cổ Đại",
        input: "https://www.nettruyen.dev/tim-truyen/co-dai",
        script: "gen.js"
    }, {
        title: "Doujinshi",
        input: "https://www.nettruyen.dev/tim-truyen/doujinshi",
        script: "gen.js"
    }, {
        title: "Drama",
        input: "https://www.nettruyen.dev/tim-truyen/drama",
        script: "gen.js"
    }, {
        title: "Đam Mỹ",
        input: "https://www.nettruyen.dev/tim-truyen/dam-my",
        script: "gen.js"
    }, {
        title: "Ecchi",
        input: "https://www.nettruyen.dev/tim-truyen/ecchi",
        script: "gen.js"
    }, {
        title: "Fantasy",
        input: "https://www.nettruyen.dev/tim-truyen/fantasy",
        script: "gen.js"
    }, {
        title: "Gender Bender",
        input: "https://www.nettruyen.dev/tim-truyen/gender-bender",
        script: "gen.js"
    }, {
        title: "Harem",
        input: "https://www.nettruyen.dev/tim-truyen/harem",
        script: "gen.js"
    }, {
        title: "Historical",
        input: "https://www.nettruyen.dev/tim-truyen/historical",
        script: "gen.js"
    }, {
        title: "Horror",
        input: "https://www.nettruyen.dev/tim-truyen/horror",
        script: "gen.js"
    }, {
        title: "Josei",
        input: "https://www.nettruyen.dev/tim-truyen/josei",
        script: "gen.js"
    }, {
        title: "Live action",
        input: "https://www.nettruyen.dev/tim-truyen/live-action",
        script: "gen.js"
    }, {
        title: "Manga",
        input: "https://www.nettruyen.dev/tim-truyen/manga",
        script: "gen.js"
    }, {
        title: "Manhua",
        input: "https://www.nettruyen.dev/tim-truyen/manhua",
        script: "gen.js"
    }, {
        title: "Manhwa",
        input: "https://www.nettruyen.dev/tim-truyen/manhwa-11400",
        script: "gen.js"
    }, {
        title: "Martial Arts",
        input: "https://www.nettruyen.dev/tim-truyen/martial-arts",
        script: "gen.js"
    }, {
        title: "Mature",
        input: "https://www.nettruyen.dev/tim-truyen/mature",
        script: "gen.js"
    }, {
        title: "Mecha",
        input: "https://www.nettruyen.dev/tim-truyen/mecha-117",
        script: "gen.js"
    }, {
        title: "Mystery",
        input: "https://www.nettruyen.dev/tim-truyen/mystery",
        script: "gen.js"
    }, {
        title: "Ngôn Tình",
        input: "https://www.nettruyen.dev/tim-truyen/ngon-tinh",
        script: "gen.js"
    }, {
        title: "One shot",
        input: "https://www.nettruyen.dev/tim-truyen/one-shot",
        script: "gen.js"
    }, {
        title: "Psychological",
        input: "https://www.nettruyen.dev/tim-truyen/psychological",
        script: "gen.js"
    }, {
        title: "Romance",
        input: "https://www.nettruyen.dev/tim-truyen/romance",
        script: "gen.js"
    }, {
        title: "School Life",
        input: "https://www.nettruyen.dev/tim-truyen/school-life",
        script: "gen.js"
    }, {
        title: "Sci-fi",
        input: "https://www.nettruyen.dev/tim-truyen/sci-fi",
        script: "gen.js"
    }, {
        title: "Seinen",
        input: "https://www.nettruyen.dev/tim-truyen/seinen",
        script: "gen.js"
    }, {
        title: "Shoujo",
        input: "https://www.nettruyen.dev/tim-truyen/shoujo",
        script: "gen.js"
    }, {
        title: "Shoujo Ai",
        input: "https://www.nettruyen.dev/tim-truyen/shoujo-ai-126",
        script: "gen.js"
    }, {
        title: "Shounen",
        input: "https://www.nettruyen.dev/tim-truyen/shounen-127",
        script: "gen.js"
    }, {
        title: "Shounen Ai",
        input: "https://www.nettruyen.dev/tim-truyen/shounen-ai",
        script: "gen.js"
    }, {
        title: "Slice of Life",
        input: "https://www.nettruyen.dev/tim-truyen/slice-of-life",
        script: "gen.js"
    }, {
        title: "Smut",
        input: "https://www.nettruyen.dev/tim-truyen/smut",
        script: "gen.js"
    }, {
        title: "Soft Yaoi",
        input: "https://www.nettruyen.dev/tim-truyen/soft-yaoi",
        script: "gen.js"
    }, {
        title: "Soft Yuri",
        input: "https://www.nettruyen.dev/tim-truyen/soft-yuri",
        script: "gen.js"
    }, {
        title: "Sports",
        input: "https://www.nettruyen.dev/tim-truyen/sports",
        script: "gen.js"
    }, {
        title: "Supernatural",
        input: "https://www.nettruyen.dev/tim-truyen/supernatural",
        script: "gen.js"
    }, {
        title: "Tạp chí truyện tranh",
        input: "https://www.nettruyen.dev/tim-truyen/tap-chi-truyen-tranh",
        script: "gen.js"
    }, {
        title: "Thiếu Nhi",
        input: "https://www.nettruyen.dev/tim-truyen/thieu-nhi",
        script: "gen.js"
    }, {
        title: "Tragedy",
        input: "https://www.nettruyen.dev/tim-truyen/tragedy",
        script: "gen.js"
    }, {
        title: "Trinh Thám",
        input: "https://www.nettruyen.dev/tim-truyen/trinh-tham",
        script: "gen.js"
    }, {
        title: "Truyện scan",
        input: "https://www.nettruyen.dev/tim-truyen/truyen-scan",
        script: "gen.js"
    }, {
        title: "Truyện Màu",
        input: "https://www.nettruyen.dev/tim-truyen/truyen-mau",
        script: "gen.js"
    }, {
        title: "Việt Nam",
        input: "https://www.nettruyen.dev/tim-truyen/viet-nam",
        script: "gen.js"
    }, {
        title: "Webtoon",
        input: "https://www.nettruyen.dev/tim-truyen/webtoon",
        script: "gen.js"
    }, {
        title: "Xuyên Không",
        input: "https://www.nettruyen.dev/tim-truyen/xuyen-khong",
        script: "gen.js"
    }, {
        title: "16+",
        input: "https://www.nettruyen.dev/tim-truyen/16",
        script: "gen.js"
    }]);
}