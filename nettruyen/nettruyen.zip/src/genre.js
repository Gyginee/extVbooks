function execute() {
    return Response.success([{
        title: "Tất cả thể loại",
        input: "https://nettruyen.dev/the-loai",
        script: "gen.js"
    }, {
        title: "Action",
        input: "https://nettruyen.dev/the-loai/action",
        script: "gen.js"
    }, {
        title: "Adult",
        input: "https://nettruyen.dev/the-loai/truong-thanh",
        script: "gen.js"
    }, {
        title: "Adventure",
        input: "https://nettruyen.dev/the-loai/adventure",
        script: "gen.js"
    }, {
        title: "Anime",
        input: "https://nettruyen.dev/the-loai/anime",
        script: "gen.js"
    }, {
        title: "Chuyển Sinh",
        input: "https://nettruyen.dev/the-loai/chuyen-sinh",
        script: "gen.js"
    }, {
        title: "Comedy",
        input: "https://nettruyen.dev/the-loai/comedy",
        script: "gen.js"
    }, {
        title: "Comic",
        input: "https://nettruyen.dev/the-loai/comic",
        script: "gen.js"
    }, {
        title: "Cooking",
        input: "https://nettruyen.dev/the-loai/cooking",
        script: "gen.js"
    }, {
        title: "Cổ Đại",
        input: "https://nettruyen.dev/the-loai/co-dai",
        script: "gen.js"
    }, {
        title: "Doujinshi",
        input: "https://nettruyen.dev/the-loai/doujinshi",
        script: "gen.js"
    }, {
        title: "Drama",
        input: "https://nettruyen.dev/the-loai/drama",
        script: "gen.js"
    }, {
        title: "Đam Mỹ",
        input: "https://nettruyen.dev/the-loai/dam-my",
        script: "gen.js"
    }, {
        title: "Ecchi",
        input: "https://nettruyen.dev/the-loai/ecchi",
        script: "gen.js"
    }, {
        title: "Fantasy",
        input: "https://nettruyen.dev/the-loai/fantasy",
        script: "gen.js"
    }, {
        title: "Gender Bender",
        input: "https://nettruyen.dev/the-loai/gender-bender",
        script: "gen.js"
    }, {
        title: "Harem",
        input: "https://nettruyen.dev/the-loai/harem",
        script: "gen.js"
    }, {
        title: "Historical",
        input: "https://nettruyen.dev/the-loai/historical",
        script: "gen.js"
    }, {
        title: "Horror",
        input: "https://nettruyen.dev/the-loai/horror",
        script: "gen.js"
    }, {
        title: "Josei",
        input: "https://nettruyen.dev/the-loai/josei",
        script: "gen.js"
    }, {
        title: "Live action",
        input: "https://nettruyen.dev/the-loai/live-action",
        script: "gen.js"
    }, {
        title: "Manga",
        input: "https://nettruyen.dev/the-loai/manga",
        script: "gen.js"
    }, {
        title: "Manhua",
        input: "https://nettruyen.dev/the-loai/manhua",
        script: "gen.js"
    }, {
        title: "Manhwa",
        input: "https://nettruyen.dev/the-loai/manhwa-11400",
        script: "gen.js"
    }, {
        title: "Martial Arts",
        input: "https://nettruyen.dev/the-loai/martial-arts",
        script: "gen.js"
    }, {
        title: "Mature",
        input: "https://nettruyen.dev/the-loai/mature",
        script: "gen.js"
    }, {
        title: "Mecha",
        input: "https://nettruyen.dev/the-loai/mecha-117",
        script: "gen.js"
    }, {
        title: "Mystery",
        input: "https://nettruyen.dev/the-loai/mystery",
        script: "gen.js"
    }, {
        title: "Ngôn Tình",
        input: "https://nettruyen.dev/the-loai/ngon-tinh",
        script: "gen.js"
    }, {
        title: "One shot",
        input: "https://nettruyen.dev/the-loai/one-shot",
        script: "gen.js"
    }, {
        title: "Psychological",
        input: "https://nettruyen.dev/the-loai/psychological",
        script: "gen.js"
    }, {
        title: "Romance",
        input: "https://nettruyen.dev/the-loai/romance",
        script: "gen.js"
    }, {
        title: "School Life",
        input: "https://nettruyen.dev/the-loai/school-life",
        script: "gen.js"
    }, {
        title: "Sci-fi",
        input: "https://nettruyen.dev/the-loai/sci-fi",
        script: "gen.js"
    }, {
        title: "Seinen",
        input: "https://nettruyen.dev/the-loai/seinen",
        script: "gen.js"
    }, {
        title: "Shoujo",
        input: "https://nettruyen.dev/the-loai/shoujo",
        script: "gen.js"
    }, {
        title: "Shoujo Ai",
        input: "https://nettruyen.dev/the-loai/shoujo-ai-126",
        script: "gen.js"
    }, {
        title: "Shounen",
        input: "https://nettruyen.dev/the-loai/shounen-127",
        script: "gen.js"
    }, {
        title: "Shounen Ai",
        input: "https://nettruyen.dev/the-loai/shounen-ai",
        script: "gen.js"
    }, {
        title: "Slice of Life",
        input: "https://nettruyen.dev/the-loai/slice-of-life",
        script: "gen.js"
    }, {
        title: "Smut",
        input: "https://nettruyen.dev/the-loai/smut",
        script: "gen.js"
    }, {
        title: "Soft Yaoi",
        input: "https://nettruyen.dev/the-loai/soft-yaoi",
        script: "gen.js"
    }, {
        title: "Soft Yuri",
        input: "https://nettruyen.dev/the-loai/soft-yuri",
        script: "gen.js"
    }, {
        title: "Sports",
        input: "https://nettruyen.dev/the-loai/sports",
        script: "gen.js"
    }, {
        title: "Supernatural",
        input: "https://nettruyen.dev/the-loai/supernatural",
        script: "gen.js"
    }, {
        title: "Tạp chí truyện tranh",
        input: "https://nettruyen.dev/the-loai/tap-chi-truyen-tranh",
        script: "gen.js"
    }, {
        title: "Thiếu Nhi",
        input: "https://nettruyen.dev/the-loai/thieu-nhi",
        script: "gen.js"
    }, {
        title: "Tragedy",
        input: "https://nettruyen.dev/the-loai/tragedy",
        script: "gen.js"
    }, {
        title: "Trinh Thám",
        input: "https://nettruyen.dev/the-loai/trinh-tham",
        script: "gen.js"
    }, {
        title: "Truyện scan",
        input: "https://nettruyen.dev/the-loai/truyen-scan",
        script: "gen.js"
    }, {
        title: "Truyện Màu",
        input: "https://nettruyen.dev/the-loai/truyen-mau",
        script: "gen.js"
    }, {
        title: "Việt Nam",
        input: "https://nettruyen.dev/the-loai/viet-nam",
        script: "gen.js"
    }, {
        title: "Webtoon",
        input: "https://nettruyen.dev/the-loai/webtoon",
        script: "gen.js"
    }, {
        title: "Xuyên Không",
        input: "https://nettruyen.dev/the-loai/xuyen-khong",
        script: "gen.js"
    }, {
        title: "16+",
        input: "https://nettruyen.dev/the-loai/16",
        script: "gen.js"
    }]);
}